﻿
namespace PrisonManagementSystem
{
    partial class FormInteriorMinister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInteriorMinister));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLawyerRecords = new System.Windows.Forms.Button();
            this.btnJailerRecords = new System.Windows.Forms.Button();
            this.btnPrisonerRecords = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prisonerRecordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.lawyerRecordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.jailerRecordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.visitorRecordsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.prisonerRecordsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.lawyerRecordsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.jailerRecordsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.visitorRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updatePrisonerRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateLawyerRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateJailerRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateVisitorRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prisonerRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lawyerRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jailerRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visitorRecordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myPrifileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnLawyerRecords);
            this.panel1.Controls.Add(this.btnJailerRecords);
            this.panel1.Controls.Add(this.btnPrisonerRecords);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1094, 385);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(850, 93);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(174, 143);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(587, 93);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(174, 143);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(322, 93);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(174, 143);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(74, 93);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(174, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(831, 242);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(225, 42);
            this.button1.TabIndex = 14;
            this.button1.Text = " Visitor Records";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLawyerRecords
            // 
            this.btnLawyerRecords.AutoSize = true;
            this.btnLawyerRecords.BackColor = System.Drawing.Color.White;
            this.btnLawyerRecords.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLawyerRecords.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLawyerRecords.Location = new System.Drawing.Point(294, 242);
            this.btnLawyerRecords.Name = "btnLawyerRecords";
            this.btnLawyerRecords.Size = new System.Drawing.Size(225, 42);
            this.btnLawyerRecords.TabIndex = 12;
            this.btnLawyerRecords.Text = "Lawyer Records";
            this.btnLawyerRecords.UseVisualStyleBackColor = false;
            this.btnLawyerRecords.Click += new System.EventHandler(this.btnLawyerRecords_Click);
            this.btnLawyerRecords.MouseLeave += new System.EventHandler(this.btnLawyerRecords_MouseLeave);
            this.btnLawyerRecords.MouseHover += new System.EventHandler(this.btnLawyerRecords_MouseHover);
            // 
            // btnJailerRecords
            // 
            this.btnJailerRecords.AutoSize = true;
            this.btnJailerRecords.BackColor = System.Drawing.Color.Navy;
            this.btnJailerRecords.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJailerRecords.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnJailerRecords.Location = new System.Drawing.Point(38, 242);
            this.btnJailerRecords.Name = "btnJailerRecords";
            this.btnJailerRecords.Size = new System.Drawing.Size(225, 42);
            this.btnJailerRecords.TabIndex = 11;
            this.btnJailerRecords.Text = "Jailer Records";
            this.btnJailerRecords.UseVisualStyleBackColor = false;
            this.btnJailerRecords.Click += new System.EventHandler(this.prisonerRecordsToolStripMenuItem_Click);
            this.btnJailerRecords.MouseLeave += new System.EventHandler(this.btnJailerRecords_MouseLeave);
            this.btnJailerRecords.MouseHover += new System.EventHandler(this.btnJailerRecords_MouseHover);
            // 
            // btnPrisonerRecords
            // 
            this.btnPrisonerRecords.AutoSize = true;
            this.btnPrisonerRecords.BackColor = System.Drawing.Color.Orange;
            this.btnPrisonerRecords.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrisonerRecords.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnPrisonerRecords.Location = new System.Drawing.Point(566, 242);
            this.btnPrisonerRecords.Name = "btnPrisonerRecords";
            this.btnPrisonerRecords.Size = new System.Drawing.Size(225, 42);
            this.btnPrisonerRecords.TabIndex = 10;
            this.btnPrisonerRecords.Text = "Prisoner Records";
            this.btnPrisonerRecords.UseVisualStyleBackColor = false;
            this.btnPrisonerRecords.Click += new System.EventHandler(this.btnPrisonerRecords_Click);
            this.btnPrisonerRecords.MouseLeave += new System.EventHandler(this.btnPrisonerRecords_MouseLeave);
            this.btnPrisonerRecords.MouseHover += new System.EventHandler(this.btnPrisonerRecords_MouseHover);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.myPrifileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1094, 28);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateToolStripMenuItem,
            this.viewToolStripMenuItem1,
            this.myProfileToolStripMenuItem,
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fileToolStripMenuItem.Image")));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(84, 24);
            this.fileToolStripMenuItem.Text = "Home";
            // 
            // updateToolStripMenuItem
            // 
            this.updateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prisonerRecordsToolStripMenuItem1,
            this.lawyerRecordsToolStripMenuItem1,
            this.jailerRecordsToolStripMenuItem1,
            this.visitorRecordsToolStripMenuItem2});
            this.updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            this.updateToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.updateToolStripMenuItem.Text = "Update";
            // 
            // prisonerRecordsToolStripMenuItem1
            // 
            this.prisonerRecordsToolStripMenuItem1.Name = "prisonerRecordsToolStripMenuItem1";
            this.prisonerRecordsToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.prisonerRecordsToolStripMenuItem1.Text = "Prisoner Records";
            this.prisonerRecordsToolStripMenuItem1.Click += new System.EventHandler(this.prisonerRecordsToolStripMenuItem1_Click);
            // 
            // lawyerRecordsToolStripMenuItem1
            // 
            this.lawyerRecordsToolStripMenuItem1.Name = "lawyerRecordsToolStripMenuItem1";
            this.lawyerRecordsToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.lawyerRecordsToolStripMenuItem1.Text = "Lawyer Records";
            this.lawyerRecordsToolStripMenuItem1.Click += new System.EventHandler(this.lawyerRecordsToolStripMenuItem1_Click);
            // 
            // jailerRecordsToolStripMenuItem1
            // 
            this.jailerRecordsToolStripMenuItem1.Name = "jailerRecordsToolStripMenuItem1";
            this.jailerRecordsToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.jailerRecordsToolStripMenuItem1.Text = "Jailer Records";
            this.jailerRecordsToolStripMenuItem1.Click += new System.EventHandler(this.jailerRecordsToolStripMenuItem1_Click);
            // 
            // visitorRecordsToolStripMenuItem2
            // 
            this.visitorRecordsToolStripMenuItem2.Name = "visitorRecordsToolStripMenuItem2";
            this.visitorRecordsToolStripMenuItem2.Size = new System.Drawing.Size(224, 26);
            this.visitorRecordsToolStripMenuItem2.Text = "Visitor Records";
            this.visitorRecordsToolStripMenuItem2.Click += new System.EventHandler(this.visitorRecordsToolStripMenuItem2_Click);
            // 
            // viewToolStripMenuItem1
            // 
            this.viewToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prisonerRecordsToolStripMenuItem2,
            this.lawyerRecordsToolStripMenuItem2,
            this.jailerRecordsToolStripMenuItem2,
            this.visitorRecordsToolStripMenuItem});
            this.viewToolStripMenuItem1.Name = "viewToolStripMenuItem1";
            this.viewToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.viewToolStripMenuItem1.Text = "View";
            // 
            // prisonerRecordsToolStripMenuItem2
            // 
            this.prisonerRecordsToolStripMenuItem2.Name = "prisonerRecordsToolStripMenuItem2";
            this.prisonerRecordsToolStripMenuItem2.Size = new System.Drawing.Size(224, 26);
            this.prisonerRecordsToolStripMenuItem2.Text = "Prisoner Records";
            this.prisonerRecordsToolStripMenuItem2.Click += new System.EventHandler(this.prisonerRecordsToolStripMenuItem2_Click);
            // 
            // lawyerRecordsToolStripMenuItem2
            // 
            this.lawyerRecordsToolStripMenuItem2.Name = "lawyerRecordsToolStripMenuItem2";
            this.lawyerRecordsToolStripMenuItem2.Size = new System.Drawing.Size(224, 26);
            this.lawyerRecordsToolStripMenuItem2.Text = "Lawyer Records";
            this.lawyerRecordsToolStripMenuItem2.Click += new System.EventHandler(this.lawyerRecordsToolStripMenuItem2_Click);
            // 
            // jailerRecordsToolStripMenuItem2
            // 
            this.jailerRecordsToolStripMenuItem2.Name = "jailerRecordsToolStripMenuItem2";
            this.jailerRecordsToolStripMenuItem2.Size = new System.Drawing.Size(224, 26);
            this.jailerRecordsToolStripMenuItem2.Text = "Jailer Records";
            this.jailerRecordsToolStripMenuItem2.Click += new System.EventHandler(this.jailerRecordsToolStripMenuItem2_Click);
            // 
            // visitorRecordsToolStripMenuItem
            // 
            this.visitorRecordsToolStripMenuItem.Name = "visitorRecordsToolStripMenuItem";
            this.visitorRecordsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.visitorRecordsToolStripMenuItem.Text = "Visitor Records";
            this.visitorRecordsToolStripMenuItem.Click += new System.EventHandler(this.visitorRecordsToolStripMenuItem_Click);
            // 
            // myProfileToolStripMenuItem
            // 
            this.myProfileToolStripMenuItem.Name = "myProfileToolStripMenuItem";
            this.myProfileToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.myProfileToolStripMenuItem.Text = "My Profile";
            this.myProfileToolStripMenuItem.Click += new System.EventHandler(this.myProfileToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updatePrisonerRecordsToolStripMenuItem,
            this.updateLawyerRecordsToolStripMenuItem,
            this.updateJailerRecordsToolStripMenuItem,
            this.updateVisitorRecordsToolStripMenuItem});
            this.editToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editToolStripMenuItem.Image")));
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(69, 24);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // updatePrisonerRecordsToolStripMenuItem
            // 
            this.updatePrisonerRecordsToolStripMenuItem.Name = "updatePrisonerRecordsToolStripMenuItem";
            this.updatePrisonerRecordsToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.updatePrisonerRecordsToolStripMenuItem.Text = "Update Prisoner Records";
            this.updatePrisonerRecordsToolStripMenuItem.Click += new System.EventHandler(this.updatePrisonerRecordsToolStripMenuItem_Click);
            // 
            // updateLawyerRecordsToolStripMenuItem
            // 
            this.updateLawyerRecordsToolStripMenuItem.Name = "updateLawyerRecordsToolStripMenuItem";
            this.updateLawyerRecordsToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.updateLawyerRecordsToolStripMenuItem.Text = "Update Lawyer Records";
            this.updateLawyerRecordsToolStripMenuItem.Click += new System.EventHandler(this.updateLawyerRecordsToolStripMenuItem_Click);
            // 
            // updateJailerRecordsToolStripMenuItem
            // 
            this.updateJailerRecordsToolStripMenuItem.Name = "updateJailerRecordsToolStripMenuItem";
            this.updateJailerRecordsToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.updateJailerRecordsToolStripMenuItem.Text = "Update Jailer Records";
            this.updateJailerRecordsToolStripMenuItem.Click += new System.EventHandler(this.updateJailerRecordsToolStripMenuItem_Click);
            // 
            // updateVisitorRecordsToolStripMenuItem
            // 
            this.updateVisitorRecordsToolStripMenuItem.Name = "updateVisitorRecordsToolStripMenuItem";
            this.updateVisitorRecordsToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.updateVisitorRecordsToolStripMenuItem.Text = "Update Visitor Records";
            this.updateVisitorRecordsToolStripMenuItem.Click += new System.EventHandler(this.updateVisitorRecordsToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prisonerRecordsToolStripMenuItem,
            this.lawyerRecordsToolStripMenuItem,
            this.jailerRecordsToolStripMenuItem,
            this.visitorRecordsToolStripMenuItem1});
            this.viewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("viewToolStripMenuItem.Image")));
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // prisonerRecordsToolStripMenuItem
            // 
            this.prisonerRecordsToolStripMenuItem.Name = "prisonerRecordsToolStripMenuItem";
            this.prisonerRecordsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.prisonerRecordsToolStripMenuItem.Text = "Prisoner Records";
            this.prisonerRecordsToolStripMenuItem.Click += new System.EventHandler(this.prisonerRecordsToolStripMenuItem_Click);
            // 
            // lawyerRecordsToolStripMenuItem
            // 
            this.lawyerRecordsToolStripMenuItem.Name = "lawyerRecordsToolStripMenuItem";
            this.lawyerRecordsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lawyerRecordsToolStripMenuItem.Text = "Lawyer Records";
            this.lawyerRecordsToolStripMenuItem.Click += new System.EventHandler(this.lawyerRecordsToolStripMenuItem_Click);
            // 
            // jailerRecordsToolStripMenuItem
            // 
            this.jailerRecordsToolStripMenuItem.Name = "jailerRecordsToolStripMenuItem";
            this.jailerRecordsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.jailerRecordsToolStripMenuItem.Text = "Jailer Records";
            this.jailerRecordsToolStripMenuItem.Click += new System.EventHandler(this.jailerRecordsToolStripMenuItem_Click);
            // 
            // visitorRecordsToolStripMenuItem1
            // 
            this.visitorRecordsToolStripMenuItem1.Name = "visitorRecordsToolStripMenuItem1";
            this.visitorRecordsToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.visitorRecordsToolStripMenuItem1.Text = "Visitor Records";
            this.visitorRecordsToolStripMenuItem1.Click += new System.EventHandler(this.visitorRecordsToolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // myPrifileToolStripMenuItem
            // 
            this.myPrifileToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("myPrifileToolStripMenuItem.Image")));
            this.myPrifileToolStripMenuItem.Name = "myPrifileToolStripMenuItem";
            this.myPrifileToolStripMenuItem.Size = new System.Drawing.Size(105, 24);
            this.myPrifileToolStripMenuItem.Text = "My Prifile";
            this.myPrifileToolStripMenuItem.Click += new System.EventHandler(this.myPrifileToolStripMenuItem_Click);
            // 
            // FormInteriorMinister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 379);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "FormInteriorMinister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormInteriorMinister";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLawyerRecords;
        private System.Windows.Forms.Button btnJailerRecords;
        private System.Windows.Forms.Button btnPrisonerRecords;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prisonerRecordsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem lawyerRecordsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem jailerRecordsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem prisonerRecordsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem lawyerRecordsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem jailerRecordsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem myProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updatePrisonerRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateLawyerRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateJailerRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prisonerRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lawyerRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jailerRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myPrifileToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem visitorRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateVisitorRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visitorRecordsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem visitorRecordsToolStripMenuItem2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}